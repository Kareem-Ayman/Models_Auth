<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/share-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.shareReport',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cleareverything' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FRUX5Cm75dnEpThO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/checklogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.checklogin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/emailVerify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.emailVerify',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/phoneVerify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.phoneVerify',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/phone_verify_done' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.phone_verify_done',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.register',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/refreshToken' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.refreshToken',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/send_forget' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.send_forget',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/receive_forget' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.receive_forget',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reset_pass_forget' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.reset_pass_forget',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/_ignition/s(?|cripts/([^/]++)(*:37)|tyles/([^/]++)(*:58))|/api/email_verify_done/([^/]++)(*:97))/?$}sDu',
    ),
    3 => 
    array (
      37 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.scripts',
          ),
          1 => 
          array (
            0 => 'script',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      58 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.styles',
          ),
          1 => 
          array (
            0 => 'style',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.email_verify_done',
          ),
          1 => 
          array (
            0 => '_code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionEnabled',
        ),
        'uses' => 'Facade\\Ignition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Facade\\Ignition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionEnabled',
          1 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionConfigValueEnabled:enableRunnableSolutions',
        ),
        'uses' => 'Facade\\Ignition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Facade\\Ignition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ignition.shareReport' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/share-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionEnabled',
          1 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionConfigValueEnabled:enableShareButton',
        ),
        'uses' => 'Facade\\Ignition\\Http\\Controllers\\ShareReportController@__invoke',
        'controller' => 'Facade\\Ignition\\Http\\Controllers\\ShareReportController',
        'as' => 'ignition.shareReport',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ignition.scripts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/scripts/{script}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionEnabled',
        ),
        'uses' => 'Facade\\Ignition\\Http\\Controllers\\ScriptController@__invoke',
        'controller' => 'Facade\\Ignition\\Http\\Controllers\\ScriptController',
        'as' => 'ignition.scripts',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'ignition.styles' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/styles/{style}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Facade\\Ignition\\Http\\Middleware\\IgnitionEnabled',
        ),
        'uses' => 'Facade\\Ignition\\Http\\Controllers\\StyleController@__invoke',
        'controller' => 'Facade\\Ignition\\Http\\Controllers\\StyleController',
        'as' => 'ignition.styles',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FRUX5Cm75dnEpThO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/cleareverything',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@cleareverything',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@cleareverything',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::FRUX5Cm75dnEpThO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.email_verify_done' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/email_verify_done/{_code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@email_verify_done',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@email_verify_done',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.email_verify_done',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.checklogin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/checklogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@checkLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@checkLogin',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.checklogin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.emailVerify' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/emailVerify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@emailVerify',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@emailVerify',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.emailVerify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.phoneVerify' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/phoneVerify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@phoneVerify',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@phoneVerify',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.phoneVerify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.phone_verify_done' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/phone_verify_done',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@phone_verify_done',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@phone_verify_done',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.phone_verify_done',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.register' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.refreshToken' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/refreshToken',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@refreshToken',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@refreshToken',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.refreshToken',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.send_forget' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/send_forget',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\ForgetPasswordController@send_forget',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\ForgetPasswordController@send_forget',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.send_forget',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.receive_forget' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/receive_forget',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\ForgetPasswordController@receive_forget',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\ForgetPasswordController@receive_forget',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.receive_forget',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.reset_pass_forget' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reset_pass_forget',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\ForgetPasswordController@reset_pass_forget',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\ForgetPasswordController@reset_pass_forget',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.reset_pass_forget',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);

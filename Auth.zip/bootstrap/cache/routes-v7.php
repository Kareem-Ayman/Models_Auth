<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/cleareverything' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Pb6h9Z6ci6EiKdDA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/email_verify_done_request' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.email_verify_done_request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/checklogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.checklogin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/emailVerify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.emailVerify',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.register',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/email_verify_done/([^/]++)/([^/]++)(*:47))/?$}sDu',
    ),
    3 => 
    array (
      47 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.email_verify_done',
          ),
          1 => 
          array (
            0 => '_token',
            1 => '_code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::Pb6h9Z6ci6EiKdDA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/cleareverything',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@cleareverything',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@cleareverything',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Pb6h9Z6ci6EiKdDA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.email_verify_done' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/email_verify_done/{_token}/{_code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@email_verify_done',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@email_verify_done',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.email_verify_done',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.email_verify_done_request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/email_verify_done_request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@email_verify_done_request',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@email_verify_done_request',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.email_verify_done_request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.checklogin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/checklogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@checkLogin',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@checkLogin',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.checklogin',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.emailVerify' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/emailVerify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'auth_gurad:user_api',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@emailVerify',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\VerificationController@emailVerify',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.emailVerify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.register' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'localeSessionRedirect',
          2 => 'localizationRedirect',
          3 => 'localeViewPath',
          4 => 'getLang',
          5 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Site\\Api\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers\\Site\\Api',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'user.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
